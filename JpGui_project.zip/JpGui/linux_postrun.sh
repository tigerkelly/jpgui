#! /usr/bin/sh
# PostRun script for project JpGui

# Place your code below this line.
# Keep your code above this line.

exit 0

# Function to delete files.  Usage: REMOVE filepath
REMOVE()
{
rm -rf $1 >/dev/null 2>&1
if [ $? -ne 0 ]; then
    echo PostRun: Delete of %1 failed.
    exit 1
fi
}
