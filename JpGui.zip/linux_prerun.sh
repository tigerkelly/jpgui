#! /usr/bin/sh
# PreRun script for project JpGui

# Place your code below this line.
# Keep your code above this line.

exit 0

# Function to copy to input directory (jpackage --input).  Usage: CP filepath
CP()
{
cp $1 C:\Users\kellyw\JpGui\projects\JpGui\win_in >/dev/null 2>&1
if [ $? -ne 0 ]; then
    echo PreRun: Copy of $1 failed.
    exit 1
fi
}
